<?php
namespace Modules\buysell\Controllers;
use core\CoreClasses\services\Controller;
use core\CoreClasses\db\dbaccess;
use Modules\buysell\Entity\buysell_componentEntity;
use Modules\buysell\Entity\buysell_componentphotoEntity;
use Modules\buysell\PublicClasses\Constants;
use Modules\common\Entity\common_countryEntity;
use Modules\languages\PublicClasses\CurrentLanguageManager;
/**
*@author Hadi AmirNahavandi
*@creationDate 1395-11-27 - 2017-02-15 15:29
*@lastUpdate 1395-11-27 - 2017-02-15 15:29
*@SweetFrameworkHelperVersion 2.001
*@SweetFrameworkVersion 1.018
*/
class carlistWidgetController extends carlistController {
    
}
?>