
<?php
/**
*@SweetFrameworkHelperVersion 2.002
*@SweetFrameworkVersion 1.021
*@Date 1396-08-02 - 2017-10-24 14:14
*@Module Name onlineclass
*@ActionTitle Regenerate WholeFormFiles For purchase
*@ActionCode 1
*/
?>
<?php
/**
*@SweetFrameworkHelperVersion 2.002
*@SweetFrameworkVersion 1.021
*@Date 1396-08-02 - 2017-10-24 14:19
*@Module Name onlineclass
*@ActionTitle Regenerate WholeFormFiles For purchasecommit
*@ActionCode 1
*/
?>