<?php
namespace Modules\onlineclass\Controllers;
use core\CoreClasses\services\Controller;
use core\CoreClasses\Exception\DataNotFoundException;
use core\CoreClasses\db\dbaccess;
use Modules\languages\PublicClasses\CurrentLanguageManager;
use Modules\users\PublicClasses\sessionuser;
use core\CoreClasses\db\QueryLogic;
use core\CoreClasses\db\FieldCondition;
use core\CoreClasses\db\LogicalOperator;
use Modules\onlineclass\Entity\onlineclass_levelEntity;
/**
*@author Hadi AmirNahavandi
*@creationDate 1396-07-25 - 2017-10-17 15:53
*@lastUpdate 1396-07-25 - 2017-10-17 15:53
*@SweetFrameworkHelperVersion 2.002
*@SweetFrameworkVersion 2.002
*/
class managelevelsController extends levellistController {
	private $PAGESIZE=10;
	public function DeleteItem($ID)
	{
		$Language_fid=CurrentLanguageManager::getCurrentLanguageID();
		$DBAccessor=new dbaccess();
		$su=new sessionuser();
        $role_systemuser_fid=$su->getSystemUserID();
        $UserID=null;
        if(!$this->getAdminMode())
            $UserID=$role_systemuser_fid;
		$levelEnt=new onlineclass_levelEntity($DBAccessor);
		$levelEnt->setId($ID);
		if($levelEnt->getId()==-1)
			throw new DataNotFoundException();
		if($UserID!=null && $levelEnt->getRole_systemuser_fid()!=$UserID)
			throw new DataNotFoundException();
		$levelEnt->Remove();
		$DBAccessor->close_connection();
		return $this->load(-1);
	}
}
?>