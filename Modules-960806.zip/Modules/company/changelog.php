<?php
/**
*SweetFrameworkHelper Version 1.102
*Module Name:company
*Date:2015/02/19 13:42:01
*ChangedOrUpdated:company_product
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.102
*Module Name:company
*Date:2015/02/19 15:52:58
*ChangedOrUpdated:company_customer
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.102
*Module Name:company
*Date:2015/02/19 15:54:05
*ChangedOrUpdated:lastcustomers
**/
?>

<?php
/**
*Module Name:company
*Date:2015/03/11 18:28:08
*ChangedOrUpdated:lastcustomers and products
*1-Added getCanonicalURL to both pages
**/
?>
<?php
/**
*@SweetFrameworkHelperVersion 2.002
*@SweetFrameworkVersion 1.021
*@Date 1396-06-28 - 2017-09-19 17:32
*@Module Name company
*@ActionTitle Regenerate WholeFormFiles For orderhome
*@ActionCode 1
*/
?>
<?php
/**
*@SweetFrameworkHelperVersion 2.002
*@SweetFrameworkVersion 1.021
*@Date 1396-06-28 - 2017-09-19 17:35
*@Module Name company
*@ActionTitle Regenerate WholeFormFiles For orderhome
*@ActionCode 1
*/
?>
<?php
/**
*@SweetFrameworkHelperVersion 2.002
*@SweetFrameworkVersion 1.021
*@Date 1396-06-28 - 2017-09-19 17:36
*@Module Name company
*@ActionTitle Regenerate WholeFormFiles For orderhome
*@ActionCode 1
*/
?>