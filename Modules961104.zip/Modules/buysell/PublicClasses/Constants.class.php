<?php
namespace Modules\buysell\PublicClasses;
/**
 * Created by PhpStorm.
 * User: Hadi
 * Date: 15/02/2017
 * Time: 13:15
 */
class Constants
{
public static $MAXPHOTOCOUNT=4;
}