<?php
namespace Modules\fileshop\Forms;
use core\CoreClasses\services\FormDesign;
use core\CoreClasses\services\MessageType;
use core\CoreClasses\services\baseHTMLElement;
use core\CoreClasses\html\ListTable;
use core\CoreClasses\html\UList;
use core\CoreClasses\html\FormLabel;
use core\CoreClasses\html\UListElement;
use core\CoreClasses\html\Div;
use core\CoreClasses\html\link;
use core\CoreClasses\html\Lable;
use core\CoreClasses\html\TextBox;
use core\CoreClasses\html\DatePicker;
use core\CoreClasses\html\DataComboBox;
use core\CoreClasses\html\SweetButton;
use core\CoreClasses\html\Button;
use core\CoreClasses\html\CheckBox;
use core\CoreClasses\html\RadioBox;
use core\CoreClasses\html\SweetFrom;
use core\CoreClasses\html\ComboBox;
use core\CoreClasses\html\FileUploadBox;
use Modules\common\PublicClasses\AppRooter;
use Modules\common\PublicClasses\UrlParameter;
use core\CoreClasses\SweetDate;
/**
*@author Hadi AmirNahavandi
*@creationDate 1396-09-09 - 2017-11-30 16:33
*@lastUpdate 1396-09-09 - 2017-11-30 16:33
*@SweetFrameworkHelperVersion 2.004
*@SweetFrameworkVersion 2.004
*/
class filelistsearch_Design extends FormDesign {
	private $Data;
	/**
	 * @param mixed $Data
	 */
	public function setData($Data)
	{
		$this->Data = $Data;
	}
	/** @var textbox */
	private $title;
	/**
	 * @return textbox
	 */
	public function getTitle()
	{
		return $this->title;
	}
	/** @var DatePicker */
	private $add_date_from;
	/**
	 * @return DatePicker
	 */
	public function getAdd_date_from()
	{
		return $this->add_date_from;
	}
	/** @var DatePicker */
	private $add_date_to;
	/**
	 * @return DatePicker
	 */
	public function getAdd_date_to()
	{
		return $this->add_date_to;
	}
	/** @var textbox */
	private $description;
	/**
	 * @return textbox
	 */
	public function getDescription()
	{
		return $this->description;
	}
	/** @var textbox */
	private $price;
	/**
	 * @return textbox
	 */
	public function getPrice()
	{
		return $this->price;
	}
	/** @var textbox */
	private $filecount;
	/**
	 * @return textbox
	 */
	public function getFilecount()
	{
		return $this->filecount;
	}
	/** @var combobox */
	private $sortby;
	/**
	 * @return combobox
	 */
	public function getSortby()
	{
		return $this->sortby;
	}
	/** @var combobox */
	private $isdesc;
	/**
	 * @return combobox
	 */
	public function getIsdesc()
	{
		return $this->isdesc;
	}
	/** @var SweetButton */
	private $search;
	public function __construct()
	{
		parent::__construct();

		/******* title *******/
		$this->title= new textbox("title");
		$this->title->setClass("form-control");

		/******* add_date_from *******/
		$this->add_date_from= new DatePicker("add_date_from");
		$this->add_date_from->setClass("form-control");

		/******* add_date_to *******/
		$this->add_date_to= new DatePicker("add_date_to");
		$this->add_date_to->setClass("form-control");

		/******* description *******/
		$this->description= new textbox("description");
		$this->description->setClass("form-control");

		/******* price *******/
		$this->price= new textbox("price");
		$this->price->setClass("form-control");

		/******* filecount *******/
		$this->filecount= new textbox("filecount");
		$this->filecount->setClass("form-control");

		/******* sortby *******/
		$this->sortby= new combobox("sortby");
		$this->sortby->setClass("form-control");

		/******* isdesc *******/
		$this->isdesc= new combobox("isdesc");
		$this->isdesc->setClass("form-control");

		/******* search *******/
		$this->search= new SweetButton(true,"جستجو");
		$this->search->setAction("search");
		$this->search->setDisplayMode(Button::$DISPLAYMODE_BUTTON);
		$this->search->setClass("btn btn-primary");

		/******* Category *******/
		$this->Categorys= new  CheckBox('category[]');
	}
	public function getBodyHTML($command=null)
	{
		$this->FillItems();
		$Page=new Div();
		$Page->setClass("sweet_formtitle");
		$Page->setId("fileshop_filelist");
		$Page->addElement($this->getPageTitlePart("جستجوی " . $this->Data['file']->getTableTitle() . ""));
		if($this->getMessage()!="")
			$Page->addElement($this->getMessagePart());
		$LTable1=new Div();
		$LTable1->setClass("searchtable");
		$LTable1->addElement($this->getFieldRowCode($this->title,$this->getFieldCaption('title'),null,'',null));
		$LTable1->addElement($this->getFieldRowCode($this->add_date_from,$this->getFieldCaption('add_date_from'),null,'',null));
		$LTable1->addElement($this->getFieldRowCode($this->add_date_to,$this->getFieldCaption('add_date_to'),null,'',null));
		$LTable1->addElement($this->getFieldRowCode($this->description,$this->getFieldCaption('description'),null,'',null));
		$LTable1->addElement($this->getFieldRowCode($this->price,$this->getFieldCaption('price'),null,'',null));
		$LTable1->addElement($this->getFieldRowCode($this->filecount,$this->getFieldCaption('filecount'),null,'',null));
		$LTable1->addElement($this->getFieldRowCode($this->sortby,$this->getFieldCaption('sortby'),null,'',null));
		$LTable1->addElement($this->getFieldRowCode($this->isdesc,$this->getFieldCaption('isdesc'),null,'',null));
		$LTable1->addElement($this->getSingleFieldRowCode($this->search));
		$Page->addElement($LTable1);
		$form=new SweetFrom("", "GET", $Page);
		$form->setClass('form-horizontal');
		return $form->getHTML();
	}
	public function FillItems()
	{
		if (key_exists("file", $this->Data)){

			/******** title ********/
			$this->title->setValue($this->Data['file']->getTitle());
			$this->setFieldCaption('title',$this->Data['file']->getFieldInfo('title')->getTitle());

			/******** add_date_from ********/
			$this->add_date_from->setTime($this->Data['file']->getAdd_date_from());
			$this->setFieldCaption('add_date_from',$this->Data['file']->getFieldInfo('add_date_from')->getTitle());

			/******** add_date_to ********/
			$this->add_date_to->setTime($this->Data['file']->getAdd_date_to());
			$this->setFieldCaption('add_date_to',$this->Data['file']->getFieldInfo('add_date_to')->getTitle());
			$this->setFieldCaption('add_date',$this->Data['file']->getFieldInfo('add_date')->getTitle());

			/******** description ********/
			$this->description->setValue($this->Data['file']->getDescription());
			$this->setFieldCaption('description',$this->Data['file']->getFieldInfo('description')->getTitle());

			/******** price ********/
			$this->price->setValue($this->Data['file']->getPrice());
			$this->setFieldCaption('price',$this->Data['file']->getFieldInfo('price')->getTitle());

			/******** filecount ********/
			$this->filecount->setValue($this->Data['file']->getFilecount());
			$this->setFieldCaption('filecount',$this->Data['file']->getFieldInfo('filecount')->getTitle());

			/******** sortby ********/

			/******** isdesc ********/

			/******** search ********/
		}
			$this->isdesc->addOption('0','صعودی');
			$this->isdesc->addOption('1','نزولی');

		/******** title ********/
		$this->sortby->addOption($this->Data['file']->getTableFieldID('title'),$this->getFieldCaption('title'));
		if(isset($_GET['title']))
			$this->title->setValue($_GET['title']);

		/******** add_date_from ********/

		/******** add_date_to ********/
		$this->sortby->addOption($this->Data['file']->getTableFieldID('add_date'),$this->getFieldCaption('add_date'));

		/******** description ********/
		$this->sortby->addOption($this->Data['file']->getTableFieldID('description'),$this->getFieldCaption('description'));
		if(isset($_GET['description']))
			$this->description->setValue($_GET['description']);

		/******** price ********/
		$this->sortby->addOption($this->Data['file']->getTableFieldID('price'),$this->getFieldCaption('price'));
		if(isset($_GET['price']))
			$this->price->setValue($_GET['price']);

		/******** filecount ********/
		$this->sortby->addOption($this->Data['file']->getTableFieldID('filecount'),$this->getFieldCaption('filecount'));
		if(isset($_GET['filecount']))
			$this->filecount->setValue($_GET['filecount']);

		/******** sortby ********/
		if(isset($_GET['sortby']))
			$this->sortby->setSelectedValue($_GET['sortby']);

		/******** isdesc ********/
		if(isset($_GET['isdesc']))
			$this->isdesc->setSelectedValue($_GET['isdesc']);

		/******** search ********/
	}
}
?>