<?php
namespace Modules\sfman\Forms;
use core\CoreClasses\services\FormDesign;
use core\CoreClasses\html\ListTable;
use core\CoreClasses\html\Div;
use core\CoreClasses\html\Lable;
use core\CoreClasses\html\TextBox;
use core\CoreClasses\html\DataComboBox;
use core\CoreClasses\html\SweetButton;
use core\CoreClasses\html\CheckBox;
use core\CoreClasses\html\SweetFrom;
use core\CoreClasses\html\ComboBox;
use core\CoreClasses\html\FileUploadBox;
/**
*@author Hadi AmirNahavandi
*@creationDate 1395-11-06 - 2017-01-25 03:33
*@lastUpdate 1395-11-06 - 2017-01-25 03:33
*@SweetFrameworkHelperVersion 2.000
*@SweetFrameworkVersion 1.017
*/
class makeEntity_Design extends FormDesign {
	private $Data;
	/**
	 * @param mixed $Data
	 */
	public function setData($Data)
	{
		$this->Data = $Data;
	}
	/** @var textbox */
	private $txtModule;
	/**
	 * @return textbox
	 */
	public function getTxtModule()
	{
		return $this->txtModule;
	}
	/** @var textbox */
	private $txtEntity;
	/**
	 * @return textbox
	 */
	public function getTxtEntity()
	{
		return $this->txtEntity;
	}
	/** @var combobox */
	private $cmbFieldType;
	/**
	 * @return combobox
	 */
	public function getCmbFieldType()
	{
		return $this->cmbFieldType;
	}
	/** @var textbox */
	private $txtFieldName;
	/**
	 * @return textbox
	 */
	public function getTxtFieldName()
	{
		return $this->txtFieldName;
	}
	/** @var SweetButton */
	private $btnAddField;
	/** @var SweetButton */
	private $btnGenerate;
	public function __construct()
	{
		$this->txtModule= new textbox("txtModule");
		$this->txtEntity= new textbox("txtEntity");
		$this->cmbFieldType= new combobox("cmbFieldType");
		$this->txtFieldName= new textbox("txtFieldName");
		$this->btnAddField= new SweetButton(true,"افزودن فیلد");
		$this->btnAddField->setAction("btnAddField");
		$this->btnGenerate= new SweetButton(true,"ذخیره و تولید کد");
		$this->btnGenerate->setAction("btnGenerate");
	}
	public function getBodyHTML($command=null)
	{
		$Page=new Div();
		$Page->setId("sfman_makeEntity");
		$Page->addElement(new Lable("ساخت کلاس Entity"));
		$Page->setClass("sweet_formtitle");
		$LTable1=new ListTable(2);
        $LTable2=new ListTable(4);
        $LTable3=new ListTable(2);
        $LTable2->addElement(new Lable("ماژول"));
        $LTable2->addElement($this->txtModule);
        $LTable2->addElement(new Lable("عنوان کلاس"));
        $LTable2->addElement($this->txtEntity);
        $LTable3->addElement(new Lable("نوع فیلد"));
        $LTable3->addElement($this->cmbFieldType);
        $LTable3->addElement(new Lable("نام فیلد"));
        $LTable3->addElement($this->txtFieldName);
        $LTable3->addElement($this->btnAddField,2);
        $LTable1->addElement($LTable2,2);
        $LTable1->addElement($LTable3);
		$LTable1->addElement($this->btnGenerate,2);
		$Page->addElement($LTable1);
		$form=new SweetFrom("", "POST", $Page);
		return $form->getHTML();
	}
}
?>