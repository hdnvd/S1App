<?php
namespace Modules\sfman\Forms;
use core\CoreClasses\services\FormCode;
use Modules\languages\PublicClasses\ModuleTranslator;
use Modules\languages\PublicClasses\CurrentLanguageManager;
use Modules\sfman\Controllers\makeEntityController;
/**
*@author Hadi AmirNahavandi
*@creationDate 1395-11-06 - 2017-01-25 03:33
*@lastUpdate 1395-11-06 - 2017-01-25 03:33
*@SweetFrameworkHelperVersion 2.000
*@SweetFrameworkVersion 1.017
*/
class makeEntity_Code extends FormCode {
	public function load()
	{
		$makeEntityController=new makeEntityController();
		$translator=new ModuleTranslator("sfman");
		$translator->setLanguageName(CurrentLanguageManager::getCurrentLanguageName());
		$Result=$makeEntityController->load();
		$design=new makeEntity_Design();
		$design->setData($Result);
		return $design->getBodyHTML();
	}
	public function btnAddField_Click()
	{
		$makeEntityController=new makeEntityController();
		$translator=new ModuleTranslator("sfman");
		$translator->setLanguageName(CurrentLanguageManager::getCurrentLanguageName());
		$design=new makeEntity_Design();
		$txtModule=$design->gettxtModule()->getValue();
		$txtEntity=$design->gettxtEntity()->getValue();
		$cmbFieldType_ID=$design->getCmbFieldType()->getSelectedID();
		$txtFieldName=$design->gettxtFieldName()->getValue();
		$Result=$makeEntityController->BtnAddField($txtModule,$txtEntity,$cmbFieldType_ID,$txtFieldName);
		$design->setData($Result);
		return $design->getBodyHTML();
	}
	public function btnGenerate_Click()
	{
		$makeEntityController=new makeEntityController();
		$translator=new ModuleTranslator("sfman");
		$translator->setLanguageName(CurrentLanguageManager::getCurrentLanguageName());
		$design=new makeEntity_Design();
		$txtModule=$design->gettxtModule()->getValue();
		$txtEntity=$design->gettxtEntity()->getValue();
		$cmbFieldType_ID=$design->getCmbFieldType()->getSelectedID();
		$txtFieldName=$design->gettxtFieldName()->getValue();
		$Result=$makeEntityController->BtnGenerate($txtModule,$txtEntity,$cmbFieldType_ID,$txtFieldName);
		$design->setData($Result);
		return $design->getBodyHTML();
	}
}
?>