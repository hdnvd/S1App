<?php
/**
*SweetFrameworkHelper Version 1.109
*Module Name:sfman
*Date:2016/05/15 23:14:30
*ChangedOrUpdated:managecache
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.110
*Module Name:sfman
*Date:2016/05/16 22:50:32
*ChangedOrUpdated:module Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.110
*Module Name:sfman
*Date:2016/05/16 23:05:24
*ChangedOrUpdated:form Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.110
*Module Name:sfman
*Date:2016/05/16 23:06:44
*ChangedOrUpdated:form Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.110
*Module Name:sfman
*Date:2016/05/18 19:52:46
*ChangedOrUpdated:backup
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.110
*Module Name:sfman
*Date:2016/05/20 16:48:59
*ChangedOrUpdated:restore
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.111
*Module Name:sfman
*Date:1395/2/31 17:25:31
*ChangedOrUpdated:restore
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.111
*Module Name:sfman
*Date:1395/2/31 17:29:05
*ChangedOrUpdated:restore
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.111
*Module Name:sfman
*Date:1395/2/31 17:30:26
*ChangedOrUpdated:restore
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/3/1 - 2016/05/21 21:19:45
*ChangedOrUpdated:restore
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/3 - 2016/12/23 19:02:22
*ChangedOrUpdated:codegenerator
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/3 - 2016/12/23 19:05:34
*ChangedOrUpdated:makeform
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/3 - 2016/12/23 19:28:26
*ChangedOrUpdated:generateform
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/9 - 2016/12/29 02:03:06
*ChangedOrUpdated:generateform
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/9 - 2016/12/29 02:03:55
*ChangedOrUpdated:generateform
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/9 - 2016/12/29 02:24:45
*ChangedOrUpdated:generateform
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/9 - 2016/12/29 02:25:33
*ChangedOrUpdated:generateform
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/9 - 2016/12/29 02:42:14
*ChangedOrUpdated:manageforms
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/9 - 2016/12/29 19:34:08
*ChangedOrUpdated:manageform
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/9 - 2016/12/29 19:35:03
*ChangedOrUpdated:manageform
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/9 - 2016/12/29 19:35:46
*ChangedOrUpdated:manageform
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/9 - 2016/12/29 19:36:38
*ChangedOrUpdated:manageform
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/9 - 2016/12/29 19:45:05
*ChangedOrUpdated:manageform
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/9 - 2016/12/29 19:45:19
*ChangedOrUpdated:formelement Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/9 - 2016/12/29 19:49:56
*ChangedOrUpdated:formelement Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/9 - 2016/12/29 19:52:18
*ChangedOrUpdated:formelement Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:sfman
*Date:1395/10/12 - 2017/01/01 03:06:27
*ChangedOrUpdated:formelementtype Entity Class
**/
?>

<?php
/**
*@SweetFrameworkHelperVersion 2.000
*@SweetFrameworkVersion 1.017
*@Date 1395-11-06 - 2017-01-25 03:33
*@Module Name sfman
*@ActionTitle Regenerate WholeFormFiles For makeEntity
*@ActionCode 1
*/
?>