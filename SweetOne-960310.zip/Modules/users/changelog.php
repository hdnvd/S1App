<?php
/**
*SweetFrameworkHelper Version 1.103
*Module Name:users
*Date:2015/06/26 16:26:07
*ChangedOrUpdated:deviceinfo Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.103
*Module Name:users
*Date:2015/06/26 16:27:20
*ChangedOrUpdated:deviceinfo Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.103
*Module Name:users
*Date:2015/06/26 16:27:43
*ChangedOrUpdated:deviceinfo Entity Class
**/
?>
<?php
/**
*
*Module Name:users
*Date:2015/10/17 17:27:43
*ChangedOrUpdated:roleSystemUser Entity Class
*1-Added $DBACCESSOR to constructor
**/
?>
<?php
/**
*
*Module Name:users
*Date:2016/5/17 17:58:26
*ChangedOrUpdated:User Entity Class
*1-Added Signup Time to Fields
**/
?>

<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:users
*Date:1395/3/1 - 2016/05/21 20:34:37
*ChangedOrUpdated:manageusers
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:users
*Date:1395/3/1 - 2016/05/21 20:35:08
*ChangedOrUpdated:manageuser
**/
?>
