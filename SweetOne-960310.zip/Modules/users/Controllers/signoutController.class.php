<?php

namespace Modules\users\Controllers;
use core\CoreClasses\services\Controller;


class signoutController extends Controller {
	public function load()
	{
		return null;
	}
}
?>
