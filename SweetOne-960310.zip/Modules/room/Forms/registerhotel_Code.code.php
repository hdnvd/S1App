<?php
namespace Modules\room\Forms;
use core\CoreClasses\services\FormCode;
use Modules\languages\PublicClasses\ModuleTranslator;
use Modules\languages\PublicClasses\CurrentLanguageManager;
use Modules\room\Controllers\registerhotelController;
/**
*@author Hadi AmirNahavandi
*@creationDate 1395-11-08 - 2017-01-27 19:56
*@lastUpdate 1395-11-08 - 2017-01-27 19:56
*@SweetFrameworkHelperVersion 2.000
*@SweetFrameworkVersion 1.017
*/
class registerhotel_Code extends FormCode {
	public function load()
	{
		$registerhotelController=new registerhotelController();
		$translator=new ModuleTranslator("room");
		$translator->setLanguageName(CurrentLanguageManager::getCurrentLanguageName());
		$Result=$registerhotelController->load();
		$design=new registerhotel_Design();
		$design->setData($Result);
		return $design->getBodyHTML();
	}
	public function btnSave_Click()
	{
		$registerhotelController=new registerhotelController();
		$translator=new ModuleTranslator("room");
		$translator->setLanguageName(CurrentLanguageManager::getCurrentLanguageName());
		$design=new registerhotel_Design();
		$txtName=$design->getTxtName()->getValue();
		$cmbIsmale_ID=$design->getCmbIsmale()->getSelectedID();
		$txtNationalCode=$design->getTxtNationalCode()->getValue();
		$cmbCity_ID=$design->getCmbCity()->getSelectedID();
		$txtStreet=$design->getTxtStreet()->getValue();
		$txtAddress=$design->getTxtAddress()->getValue();
		$txtMobile=$design->getTxtMobile()->getValue();
		$txtTel=$design->getTxtTel()->getValue();
		$Result=$registerhotelController->BtnSave($txtName,$cmbIsmale_ID,$txtNationalCode,$cmbCity_ID,$txtStreet,$txtAddress,$txtMobile,$txtTel);
		$design->setData($Result);
		return $design->getBodyHTML();
	}
}
?>