<?php
namespace Modules\room\Forms;
use core\CoreClasses\services\FormDesign;
use core\CoreClasses\html\ListTable;
use core\CoreClasses\html\Div;
use core\CoreClasses\html\Lable;
use core\CoreClasses\html\TextBox;
use core\CoreClasses\html\DataComboBox;
use core\CoreClasses\html\SweetButton;
use core\CoreClasses\html\CheckBox;
use core\CoreClasses\html\SweetFrom;
use core\CoreClasses\html\ComboBox;
use core\CoreClasses\html\FileUploadBox;
/**
*@author Hadi AmirNahavandi
*@creationDate 1395-11-08 - 2017-01-27 19:56
*@lastUpdate 1395-11-08 - 2017-01-27 19:56
*@SweetFrameworkHelperVersion 2.000
*@SweetFrameworkVersion 1.017
*/
class registerhotel_Design extends FormDesign {
	private $Data;
	/**
	 * @param mixed $Data
	 */
	public function setData($Data)
	{
		$this->Data = $Data;
	}
	/** @var textbox */
	private $txtName;
	/**
	 * @return textbox
	 */
	public function getTxtName()
	{
		return $this->txtName;
	}
	/** @var combobox */
	private $cmbIsmale;
	/**
	 * @return combobox
	 */
	public function getCmbIsmale()
	{
		return $this->cmbIsmale;
	}
	/** @var textbox */
	private $txtNationalCode;
	/**
	 * @return textbox
	 */
	public function getTxtNationalCode()
	{
		return $this->txtNationalCode;
	}
	/** @var lable */
	private $lblAddress;
	/** @var combobox */
	private $cmbCity;
	/**
	 * @return combobox
	 */
	public function getCmbCity()
	{
		return $this->cmbCity;
	}
	/** @var textbox */
	private $txtStreet;
	/**
	 * @return textbox
	 */
	public function getTxtStreet()
	{
		return $this->txtStreet;
	}
	/** @var textbox */
	private $txtAddress;
	/**
	 * @return textbox
	 */
	public function getTxtAddress()
	{
		return $this->txtAddress;
	}
	/** @var textbox */
	private $txtMobile;
	/**
	 * @return textbox
	 */
	public function getTxtMobile()
	{
		return $this->txtMobile;
	}
	/** @var textbox */
	private $txtTel;
	/**
	 * @return textbox
	 */
	public function getTxtTel()
	{
		return $this->txtTel;
	}
	/** @var SweetButton */
	private $btnSave;
	public function __construct()
	{
		$this->txtName= new textbox("txtName");
		$this->cmbIsmale= new combobox("cmbIsmale");
		$this->txtNationalCode= new textbox("txtNationalCode");
		$this->lblAddress= new lable("آدرس");
		$this->cmbCity= new combobox("cmbCity");
		$this->txtStreet= new textbox("txtStreet");
		$this->txtAddress= new textbox("txtAddress");
		$this->txtMobile= new textbox("txtMobile");
		$this->txtTel= new textbox("txtTel");
		$this->btnSave= new SweetButton(true,"ذخیره");
		$this->btnSave->setAction("btnSave");
	}
	public function getBodyHTML($command=null)
	{
		$Page=new Div();
		$Page->setId("room_registerhotel");
		$Page->addElement(new Lable("ثبت نام اجاره دهنده"));
		$Page->setClass("sweet_formtitle");
		$LTable1=new ListTable(2);
		$LTable1->addElement(new Lable("نام و نام خانوادگی"));
		$LTable1->addElement($this->txtName);
		$LTable1->addElement(new Lable("جنسیت"));
		$LTable1->addElement($this->cmbIsmale);
		$LTable1->addElement(new Lable("کد ملی"));
		$LTable1->addElement($this->txtNationalCode);
		$LTable1->addElement($this->lblAddress,2);
		$LTable1->addElement(new Lable("شهر"));
		$LTable1->addElement($this->cmbCity);
		$LTable1->addElement(new Lable("خیابان"));
		$LTable1->addElement($this->txtStreet);
		$LTable1->addElement(new Lable("ادامه آدرس"));
		$LTable1->addElement($this->txtAddress);
		$LTable1->addElement(new Lable("موبایل"));
		$LTable1->addElement($this->txtMobile);
		$LTable1->addElement(new Lable("تلفن"));
		$LTable1->addElement($this->txtTel);
		$LTable1->addElement($this->btnSave,2);
		$Page->addElement($LTable1);
		$form=new SweetFrom("", "POST", $Page);
		return $form->getHTML();
	}
}
?>