
<?php
/**
*@SweetFrameworkHelperVersion 2.000
*@SweetFrameworkVersion 1.017
*@Date 1395-11-08 - 2017-01-27 19:56
*@Module Name room
*@ActionTitle Regenerate WholeFormFiles For registerhotel
*@ActionCode 1
*/
?>