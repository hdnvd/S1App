<?php
namespace Modules\test\Forms
use core\CoreClasses\services\FormDesign;
use core\CoreClasses\html\ListTable;
use core\CoreClasses\html\Div;
use core\CoreClasses\html\Lable;
use core\CoreClasses\html\TextBox;
use core\CoreClasses\html\DataComboBox;
use core\CoreClasses\html\SweetButton;
use core\CoreClasses\html\SweetFrom;
use core\CoreClasses\html\ComboBox;
use core\CoreClasses\html\FileUploadBox;
/**
*@author Hadi AmirNahavandi
*@creationDate 1395-11-02 - 2017-01-21 02:16
*@lastUpdate 1395-11-02 - 2017-01-21 02:16
*@SweetFrameworkHelperVersion 2.000
*/
class t2_Design extends FormDesign {
	private $Data;
}
/**
* @var Label
*/
private name;
?>