<?php

namespace Modules\slider\Controllers;
use core\CoreClasses\services\Controller;


class slidemanagerController extends Controller {
	public function load()
	{
		return null;
	}
}
?>
