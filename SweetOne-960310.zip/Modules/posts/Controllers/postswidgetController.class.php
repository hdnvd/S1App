<?php

namespace Modules\posts\Controllers;
use core\CoreClasses\services\Controller;


class postswidgetController extends Controller {
	public function load()
	{
		return null;
	}
}
?>
