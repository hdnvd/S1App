<?php
/**
*SweetFrameworkHelper Version 1.107
*Module Name:appman
*Date:2015/10/16 23:17:12
*ChangedOrUpdated:generatekey
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.108
*Module Name:appman
*Date:2015/10/17 00:30:36
*ChangedOrUpdated:userdevice Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.108
*Module Name:appman
*Date:2015/10/17 00:33:12
*ChangedOrUpdated:productkey Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.108
*Module Name:appman
*Date:2015/10/17 16:50:49
*ChangedOrUpdated:register
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.108
*Module Name:appman
*Date:2015/10/17 16:53:41
*ChangedOrUpdated:register
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.108
*Module Name:appman
*Date:2015/10/17 17:54:16
*ChangedOrUpdated:appuser Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.108
*Module Name:appman
*Date:2015/10/17 17:57:31
*ChangedOrUpdated:appuser Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:appman
*Date:1395/3/29 - 2016/06/18 16:12:27
*ChangedOrUpdated:ustat
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:appman
*Date:1395/3/29 - 2016/06/18 16:15:06
*ChangedOrUpdated:contact Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:appman
*Date:1395/3/29 - 2016/06/18 16:16:14
*ChangedOrUpdated:contact Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:appman
*Date:1395/3/29 - 2016/06/18 16:17:11
*ChangedOrUpdated:device Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:appman
*Date:1395/3/29 - 2016/06/18 16:17:55
*ChangedOrUpdated:device Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.112
*Module Name:appman
*Date:1395/3/29 - 2016/06/18 16:23:34
*ChangedOrUpdated:ustat
**/
?>
