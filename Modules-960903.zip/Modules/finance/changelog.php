
<?php
/**
*@SweetFrameworkHelperVersion 2.002
*@SweetFrameworkVersion 1.021
*@Date 1396-06-13 - 2017-09-04 20:51
*@Module Name finance
*@ActionTitle Regenerate WholeFormFiles For epayment
*@ActionCode 1
*/
?>
<?php
/**
*@SweetFrameworkHelperVersion 2.002
*@SweetFrameworkVersion 1.021
*@Date 1396-06-15 - 2017-09-06 16:47
*@Module Name finance
*@ActionTitle Regenerate WholeFormFiles For manualpayment
*@ActionCode 1
*/
?>