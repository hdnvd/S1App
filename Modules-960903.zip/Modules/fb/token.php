<?php
echo $_GET['code'];
?>
