<?php
/**
*SweetFramework Version:1.011
*Module Name:parameters
*Date:2016/05/18 10:23:01
*ChangedOrUpdated:parameterEntity
*1-Set method Now Inserts a new one when not found the parameter
**/
?>