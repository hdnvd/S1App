<?php
namespace Modules\finance\Exceptions;
/**
 * Created by PhpStorm.
 * User: Hadi
 * Date: 08/02/2017
 * Time: 16:20
 */
class InvalidPortalException extends \core\CoreClasses\Exception\SweetException
{

}