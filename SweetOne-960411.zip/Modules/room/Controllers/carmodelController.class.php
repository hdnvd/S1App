<?php
namespace Modules\room\Controllers;
use core\CoreClasses\services\Controller;
use core\CoreClasses\Exception\DataNotFoundException;
use core\CoreClasses\db\dbaccess;
use Modules\languages\PublicClasses\CurrentLanguageManager;
use Modules\users\PublicClasses\sessionuser;
use core\CoreClasses\db\QueryLogic;
use core\CoreClasses\db\FieldCondition;
use core\CoreClasses\db\LogicalOperator;
use Modules\room\Entity\room_carmodelEntity;
use Modules\room\Entity\room_carmakerEntity;
use Modules\room\Entity\room_logoEntity;
/**
*@author Hadi AmirNahavandi
*@creationDate 1396-04-04 - 2017-06-25 00:17
*@lastUpdate 1396-04-04 - 2017-06-25 00:17
*@SweetFrameworkHelperVersion 2.002
*@SweetFrameworkVersion 2.002
*/
class carmodelController extends Controller {
	public function load($ID)
	{
		$Language_fid=CurrentLanguageManager::getCurrentLanguageID();
		$DBAccessor=new dbaccess();
		$su=new sessionuser();
		$role_systemuser_fid=$su->getSystemUserID();
		$result=array();
		$carmodelEntityObject=new room_carmodelEntity($DBAccessor);
		if($ID!=-1){
			$carmodelEntityObject->setId($ID);
			if($carmodelEntityObject->getId()==-1)
				throw new DataNotFoundException();
			$result['carmodel']=$carmodelEntityObject;
			$carmakerEntityObject=new room_carmakerEntity($DBAccessor);
			$carmakerEntityObject->SetId($result['carmodel']->getCarmaker_fid());
			if($carmakerEntityObject->getId()==-1)
				throw new DataNotFoundException();
			$result['carmaker_fid']=$carmakerEntityObject;
		}
		$result['param1']="";
		$DBAccessor->close_connection();
		return $result;
	}
}
?>