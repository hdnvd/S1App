<?php
namespace Modules\room\Controllers;
use core\CoreClasses\services\Controller;
use core\CoreClasses\Exception\DataNotFoundException;
use core\CoreClasses\db\dbaccess;
use Modules\languages\PublicClasses\CurrentLanguageManager;
use Modules\users\PublicClasses\sessionuser;
use core\CoreClasses\db\QueryLogic;
use core\CoreClasses\db\FieldCondition;
use core\CoreClasses\db\LogicalOperator;
use Modules\room\Entity\room_carmodelEntity;
use Modules\room\Entity\room_carmakerEntity;
use Modules\room\Entity\room_logoEntity;
/**
*@author Hadi AmirNahavandi
*@creationDate 1396-04-04 - 2017-06-25 00:17
*@lastUpdate 1396-04-04 - 2017-06-25 00:17
*@SweetFrameworkHelperVersion 2.002
*@SweetFrameworkVersion 2.002
*/
class carmodellistController extends Controller {
	private $PAGESIZE=10;
	public function load($PageNum)
	{
		$Language_fid=CurrentLanguageManager::getCurrentLanguageID();
		$DBAccessor=new dbaccess();
		$su=new sessionuser();
		$role_systemuser_fid=$su->getSystemUserID();
		$result=array();
			$carmakerEntityObject=new room_carmakerEntity($DBAccessor);
			$result['carmaker_fid']=$carmakerEntityObject->FindAll(new QueryLogic());
		if($PageNum<=0)
			$PageNum=1;
		$carmodelEnt=new room_carmodelEntity($DBAccessor);
		$q=new QueryLogic();
		$allcount=$carmodelEnt->FindAllCount($q);
		$result['pagecount']=$this->getPageCount($allcount,$this->PAGESIZE);
		$q->setLimit($this->getPageRowsLimit($PageNum,$this->PAGESIZE));
		$result['data']=$carmodelEnt->FindAll($q);
		$result['param1']="";
		$DBAccessor->close_connection();
		return $result;
	}
	public function Search($PageNum,$carmaker_fid,$latintitle,$title)
	{
		$Language_fid=CurrentLanguageManager::getCurrentLanguageID();
		$DBAccessor=new dbaccess();
		$su=new sessionuser();
		$role_systemuser_fid=$su->getSystemUserID();
		$result=array();
			$carmakerEntityObject=new room_carmakerEntity($DBAccessor);
			$result['carmaker_fid']=$carmakerEntityObject->FindAll(new QueryLogic());
		if($PageNum<=0)
			$PageNum=1;
		$carmodelEnt=new room_carmodelEntity($DBAccessor);
		$q=new QueryLogic();		
$q->addCondition(new FieldCondition("carmaker_fid","%$carmaker_fid%",LogicalOperator::LIKE));		
$q->addCondition(new FieldCondition("latintitle","%$latintitle%",LogicalOperator::LIKE));		
$q->addCondition(new FieldCondition("title","%$title%",LogicalOperator::LIKE));
		$allcount=$carmodelEnt->FindAllCount($q);
		$result['pagecount']=$this->getPageCount($allcount,$this->PAGESIZE);
		$q->setLimit($this->getPageRowsLimit($PageNum,$this->PAGESIZE));
		$result['data']=$carmodelEnt->FindAll($q);
		$result['param1']="";
		$DBAccessor->close_connection();
		return $result;
	}
}
?>