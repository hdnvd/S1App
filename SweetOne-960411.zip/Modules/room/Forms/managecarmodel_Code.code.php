<?php
namespace Modules\room\Forms;
use core\CoreClasses\services\FormCode;
use Modules\languages\PublicClasses\ModuleTranslator;
use Modules\languages\PublicClasses\CurrentLanguageManager;
use core\CoreClasses\Exception\DataNotFoundException;
use Modules\room\Controllers\managecarmodelController;
use Modules\files\PublicClasses\uploadHelper;
use Modules\common\Forms\message_Design;
/**
*@author Hadi AmirNahavandi
*@creationDate 1396-04-04 - 2017-06-25 00:17
*@lastUpdate 1396-04-04 - 2017-06-25 00:17
*@SweetFrameworkHelperVersion 2.002
*@SweetFrameworkVersion 2.002
*/
class managecarmodel_Code extends FormCode {
	public function load()
	{
		$managecarmodelController=new managecarmodelController();
		$translator=new ModuleTranslator("room");
		$translator->setLanguageName(CurrentLanguageManager::getCurrentLanguageName());
		try{
			$Result=$managecarmodelController->load($this->getID());
			$design=new managecarmodel_Design();
			$design->setData($Result);
			$design->setMessage("");
		}
		catch(DataNotFoundException $dnfex){
			$design=new message_Design();
			$design->setMessage("آیتم مورد نظر پیدا نشد");
		}
		catch(\Exception $uex){
			$design=new message_Design();
			$design->setMessage("متاسفانه خطایی در اجرای دستور خواسته شده بوجود آمد.");
		}
		return $design->getBodyHTML();
	}
	public function getID()
	{
		$id=-1;
		if(isset($_GET['id']))
			$id=$_GET['id'];
		return $id;
	}
	public function btnSave_Click()
	{
		$managecarmodelController=new managecarmodelController();
		$translator=new ModuleTranslator("room");
		$translator->setLanguageName(CurrentLanguageManager::getCurrentLanguageName());
		try{
		$design=new managecarmodel_Design();
		$carmaker_fid_ID=$design->getCarmaker_fid()->getSelectedID();
		$latintitle=$design->getLatintitle()->getValue();
		$title=$design->getTitle()->getValue();
		$logo_fluPaths=$design->getLogo_flu()->getSelectedFilesTempPath();
		$logo_fluNames=$design->getLogo_flu()->getSelectedFilesName();
		$logo_fluURLs=array();
		for($fileIndex=0;$fileIndex<count($logo_fluPaths);$fileIndex++){
			$logo_fluURLs[$fileIndex]=uploadHelper::UploadFile($logo_fluPaths[$fileIndex], $logo_fluNames[$fileIndex], "content/files/room/managecarmodel/");
		}
		$Result=$managecarmodelController->BtnSave($this->getID(),$carmaker_fid_ID,$latintitle,$title,$logo_fluURLs);
		$design->setData($Result);
		$design->setMessage("btnSave is done!");
		}
		catch(DataNotFoundException $dnfex){
			$design=new message_Design();
			$design->setMessage("آیتم مورد نظر پیدا نشد");
		}
		catch(\Exception $uex){
			$design=new message_Design();
			$design->setMessage("متاسفانه خطایی در اجرای دستور خواسته شده بوجود آمد.");
		}
		return $design->getBodyHTML();
	}
}
?>