<?php
namespace Modules\room\Forms;
use core\CoreClasses\services\FormCode;
use Modules\languages\PublicClasses\ModuleTranslator;
use Modules\languages\PublicClasses\CurrentLanguageManager;
use core\CoreClasses\Exception\DataNotFoundException;
use Modules\room\Controllers\carmodellistController;
use Modules\files\PublicClasses\uploadHelper;
use Modules\common\Forms\message_Design;
/**
*@author Hadi AmirNahavandi
*@creationDate 1396-04-04 - 2017-06-25 00:17
*@lastUpdate 1396-04-04 - 2017-06-25 00:17
*@SweetFrameworkHelperVersion 2.002
*@SweetFrameworkVersion 2.002
*/
class carmodellist_Code extends FormCode {
	public function load()
	{
		$carmodellistController=new carmodellistController();
		$translator=new ModuleTranslator("room");
		$translator->setLanguageName(CurrentLanguageManager::getCurrentLanguageName());
		try{
			if(isset($_GET['action']) && $_GET['action']=="search_Click"){
				return $this->search_Click();
			}
			else
			{
				$Result=$carmodellistController->load($this->getHttpGETparameter('pn',-1));
				$design=new carmodellist_Design();
				$design->setData($Result);
				$design->setMessage("");
			}
		}
		catch(DataNotFoundException $dnfex){
			$design=new message_Design();
			$design->setMessage("آیتم مورد نظر پیدا نشد");
		}
		catch(\Exception $uex){
			$design=new message_Design();
			$design->setMessage("متاسفانه خطایی در اجرای دستور خواسته شده بوجود آمد.");
		}
		return $design->getBodyHTML();
	}
	public function search_Click()
	{
		$carmodellistController=new carmodellistController();
		$translator=new ModuleTranslator("room");
		$translator->setLanguageName(CurrentLanguageManager::getCurrentLanguageName());
		try{
		$design=new carmodellist_Design();
		$carmaker_fid_ID=$_GET['carmaker_fid'];
		$latintitle=$_GET['latintitle'];
		$title=$_GET['title'];
		$Result=$carmodellistController->Search($this->getHttpGETparameter('pn',-1),$carmaker_fid_ID,$latintitle,$title);
		$design->setData($Result);
		$design->setMessage("search is done!");
		}
		catch(DataNotFoundException $dnfex){
			$design=new message_Design();
			$design->setMessage("آیتم مورد نظر پیدا نشد");
		}
		catch(\Exception $uex){
			$design=new message_Design();
			$design->setMessage("متاسفانه خطایی در اجرای دستور خواسته شده بوجود آمد.");
		}
		return $design->getBodyHTML();
	}
}
?>