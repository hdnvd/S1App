<?php
namespace Modules\room\Forms;
use core\CoreClasses\services\FormDesign;
use core\CoreClasses\html\ListTable;
use core\CoreClasses\html\Div;
use core\CoreClasses\html\link;
use core\CoreClasses\html\Lable;
use core\CoreClasses\html\TextBox;
use core\CoreClasses\html\DataComboBox;
use core\CoreClasses\html\SweetButton;
use core\CoreClasses\html\CheckBox;
use core\CoreClasses\html\RadioBox;
use core\CoreClasses\html\SweetFrom;
use core\CoreClasses\html\ComboBox;
use core\CoreClasses\html\FileUploadBox;
use Modules\common\PublicClasses\AppRooter;
use Modules\common\PublicClasses\UrlParameter;
/**
*@author Hadi AmirNahavandi
*@creationDate 1396-04-04 - 2017-06-25 00:17
*@lastUpdate 1396-04-04 - 2017-06-25 00:17
*@SweetFrameworkHelperVersion 2.002
*@SweetFrameworkVersion 2.002
*/
class carmodel_Design extends FormDesign {
	private $Data;
	/**
	 * @param mixed $Data
	 */
	public function setData($Data)
	{
		$this->Data = $Data;
	}
	/** @var lable */
	private $carmaker_fid;
	/** @var lable */
	private $latintitle;
	/** @var lable */
	private $title;
	/** @var lable */
	private $logo_flu;
	public function __construct()
	{
		$this->carmaker_fid= new lable("carmaker_fid");
		$this->latintitle= new lable("latintitle");
		$this->title= new lable("title");
		$this->logo_flu= new lable("logo_flu");
	}
	public function getBodyHTML($command=null)
	{
		$Page=new Div();
		$Page->setClass("sweet_formtitle");
		$Page->setId("room_carmodel");
		$PageTitlePart=new Div();
		$PageTitlePart->setClass("sweet_pagetitlepart");
		$PageTitlePart->addElement(new Lable("carmodel"));
		$Page->addElement($PageTitlePart);
		$MessagePart=new Div();
		$MessagePart->setClass("sweet_messagepart");
		$MessagePart->addElement(new Lable($this->getMessage()));
		$Page->addElement($MessagePart);
		if (key_exists("carmaker_fid", $this->Data)){
			$this->carmaker_fid->setText($this->Data['carmaker_fid']->getID());
		}
		if (key_exists("carmodel", $this->Data)){
			$this->latintitle->setText($this->Data['carmodel']->getLatintitle());
		}
		if (key_exists("carmodel", $this->Data)){
			$this->title->setText($this->Data['carmodel']->getTitle());
		}
		if (key_exists("carmodel", $this->Data)){
			$this->logo_flu->setText($this->Data['carmodel']->getLogo_flu());
		}
		$LTable1=new ListTable(2);
		$LTable1->setClass("formtable");
		$LTable1->addElement(new Lable("carmaker_fid"));
		$LTable1->setLastElementClass('form_item_titlelabel');
		$LTable1->addElement($this->carmaker_fid);
		$LTable1->setLastElementClass('form_item_datalabel');
		$LTable1->addElement(new Lable("latintitle"));
		$LTable1->setLastElementClass('form_item_titlelabel');
		$LTable1->addElement($this->latintitle);
		$LTable1->setLastElementClass('form_item_datalabel');
		$LTable1->addElement(new Lable("title"));
		$LTable1->setLastElementClass('form_item_titlelabel');
		$LTable1->addElement($this->title);
		$LTable1->setLastElementClass('form_item_datalabel');
		$LTable1->addElement(new Lable("logo_flu"));
		$LTable1->setLastElementClass('form_item_titlelabel');
		$LTable1->addElement($this->logo_flu);
		$LTable1->setLastElementClass('form_item_datalabel');
		$Page->addElement($LTable1);
		$form=new SweetFrom("", "POST", $Page);
		return $form->getHTML();
	}
}
?>