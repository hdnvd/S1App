<?php
namespace Modules\room\Forms;
use core\CoreClasses\services\FormDesign;
use core\CoreClasses\html\ListTable;
use core\CoreClasses\html\Div;
use core\CoreClasses\html\link;
use core\CoreClasses\html\Lable;
use core\CoreClasses\html\TextBox;
use core\CoreClasses\html\DataComboBox;
use core\CoreClasses\html\SweetButton;
use core\CoreClasses\html\CheckBox;
use core\CoreClasses\html\RadioBox;
use core\CoreClasses\html\SweetFrom;
use core\CoreClasses\html\ComboBox;
use core\CoreClasses\html\FileUploadBox;
use Modules\common\PublicClasses\AppRooter;
use Modules\common\PublicClasses\UrlParameter;
/**
*@author Hadi AmirNahavandi
*@creationDate 1396-04-04 - 2017-06-25 00:17
*@lastUpdate 1396-04-04 - 2017-06-25 00:17
*@SweetFrameworkHelperVersion 2.002
*@SweetFrameworkVersion 2.002
*/
class carmodellist_Design extends FormDesign {
	private $Data;
	/**
	 * @param mixed $Data
	 */
	public function setData($Data)
	{
		$this->Data = $Data;
	}
	/** @var combobox */
	private $carmaker_fid;
	/**
	 * @return combobox
	 */
	public function getCarmaker_fid()
	{
		return $this->carmaker_fid;
	}
	/** @var textbox */
	private $latintitle;
	/**
	 * @return textbox
	 */
	public function getLatintitle()
	{
		return $this->latintitle;
	}
	/** @var textbox */
	private $title;
	/**
	 * @return textbox
	 */
	public function getTitle()
	{
		return $this->title;
	}
	/** @var SweetButton */
	private $search;
	public function __construct()
	{
		$this->carmaker_fid= new combobox("carmaker_fid");
		$this->latintitle= new textbox("latintitle");
		$this->title= new textbox("title");
		$this->search= new SweetButton(true,"جستجو");
		$this->search->setAction("search");
	}
	public function getBodyHTML($command=null)
	{
		foreach ($this->Data['carmaker_fid'] as $item)
			$this->carmaker_fid->addOption($item->getID(), $item->getTitle());
		if (key_exists("carmodel", $this->Data))
			$this->carmaker_fid->setSelectedValue($this->Data['carmodel']->getCarmaker_fid());
		if (key_exists("carmodel", $this->Data))
			$this->latintitle->setValue($this->Data['carmodel']->getLatintitle());
		if (key_exists("carmodel", $this->Data))
			$this->title->setValue($this->Data['carmodel']->getTitle());
		$Page=new Div();
		$Page->setClass("sweet_formtitle");
		$Page->setId("room_carmodellist");
		$PageTitlePart=new Div();
		$PageTitlePart->setClass("sweet_pagetitlepart");
		$PageTitlePart->addElement(new Lable("carmodellist"));
		$Page->addElement($PageTitlePart);
		$MessagePart=new Div();
		$MessagePart->setClass("sweet_messagepart");
		$MessagePart->addElement(new Lable($this->getMessage()));
		$Page->addElement($MessagePart);
		$LTable1=new ListTable(4);
		$LTable1->setClass("searchtable");
		$LTable1->addElement(new Lable("carmaker_fid"));
		$LTable1->setLastElementClass('form_item_caption');
		$LTable1->addElement($this->carmaker_fid);
		$LTable1->setLastElementClass('form_item_field');
		$LTable1->addElement(new Lable("latintitle"));
		$LTable1->setLastElementClass('form_item_caption');
		$LTable1->addElement($this->latintitle);
		$LTable1->setLastElementClass('form_item_field');
		$LTable1->addElement(new Lable("title"));
		$LTable1->setLastElementClass('form_item_caption');
		$LTable1->addElement($this->title);
		$LTable1->setLastElementClass('form_item_field');
		$LTable1->addElement($this->search,2);
		$LTable1->setLastElementClass('form_item_sweetbutton');
		if(isset($_GET['carmaker_fid']))
			$this->carmaker_fid->setSelectedValue($_GET['carmaker_fid']);
		if(isset($_GET['latintitle']))
			$this->latintitle->setValue($_GET['latintitle']);
		if(isset($_GET['title']))
			$this->title->setValue($_GET['title']);
		$Page->addElement($LTable1);
		$Div1=new Div();
		$Div1->setClass("list");
		if(count($this->Data['data'])==0)
		{
			if(isset($_GET['action']) && $_GET['action']=="search_Click")
				$Div1->addElement(new Lable("هیچ آیتمی با مشخصات وارد شده پیدا نشد."));
			else
				$Div1->addElement(new Lable("هیچ آیتمی برای نمایش وجود ندارد."));
		}
		for($i=0;$i<count($this->Data['data']);$i++){
		$innerDiv[$i]=new Div();
		$innerDiv[$i]->setClass("listitem");
			$url=new AppRooter('room','carmodel');
			$url->addParameter(new UrlParameter('id',$this->Data['data'][$i]->getID()));
				$Title=$this->Data['data'][$i]->getCarmaker_fid();
			if($this->Data['data'][$i]->getCarmaker_fid()=="")
				$Title='******************';
			$lbTit[$i]=new Lable($Title);
			$liTit[$i]=new link($url->getAbsoluteURL(),$lbTit[$i]);
			$innerDiv[$i]->addElement($liTit[$i]);
			$Div1->addElement($innerDiv[$i]);
		}
		$Page->addElement($Div1);
		$Page->addElement($this->getPaginationPart($this->Data['pagecount']));
		$form=new SweetFrom("", "GET", $Page);
		return $form->getHTML();
	}
	private function getPaginationPart($PageCount)
	{
		$div=new Div();
		for($i=1;$i<=$PageCount;$i++)
		{
			$RTR=null;
			if(isset($_GET['action']) && $_GET['action']=="search_Click")
				$RTR=new AppRooter("room","carmodellist");
			else
			{
				$RTR=new AppRooter("room","carmodellist");
				//$RTR->addParameter(new UrlParameter("g",$this->Data['groupid']));
			}
			$RTR->addParameter(new UrlParameter("pn",$i));
			$RTR->setAppendToCurrentParams(false);
			$lbl=new Lable($i);
			$lnk=new link($RTR->getAbsoluteURL(),$lbl);
			$div->addElement($lnk);
		}
		return $div;
	}
}
?>