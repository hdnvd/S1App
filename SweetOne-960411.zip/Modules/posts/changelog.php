<?php
/**
*SweetFramework Version:1.001
*Module Name:posts
*Date:2015/02/20 10:23:01
*ChangedOrUpdated:post
**/
?><?php
/**
*SweetFrameworkHelper Version 1.102
*Module Name:posts
*Date:2015/02/23 23:05:56
*ChangedOrUpdated:posts_tag
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.102
*Module Name:posts
*Date:2015/02/23 23:06:16
*ChangedOrUpdated:posts_posttag
**/
?>

<?php
/**
*SweetFrameworkHelper Version 1.102
*Module Name:posts
*Date:2015/02/25 11:23:00
*Updated:postmanageCTL:
*added settags and deleteposttags and edited add to support transaction and settags
*ChangedOrUpdated:postmanageController:
*Edit And Deleted Supports Tags Now
*ChangedOrUpdated:postsController:
*loadTagPosts method Added
*ChangedOrUpdated:postsCode:
*if(isset($_GET['tag'])) added
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.102
*Module Name:posts
*Date:2015/02/25 12:57:43
*ChangedOrUpdated:tags
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.102
*Module Name:posts
*Date:2015/03/02 00:31:14
*ChangedOrUpdated:posts_post
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.102
*Module Name:posts
*Date:2015/03/02 00:31:33
*ChangedOrUpdated:posts_post
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.102
*Module Name:posts
*Date:2015/03/02 00:46:25
*ChangedOrUpdated:posts_post
**/
?>


<?php
/**
*SweetFrameworkHelper Version 1.102
*Module Name:posts
*Date:2015/03/02 00:46:25
*ChangedOrUpdated:Several Files.
*1-Added Support For Keywords
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.102
*Module Name:posts
*Date:2015/03/11 12:51:14
*ChangedOrUpdated:posts_post
*1-Added CanonicalURL Field
**/
?>
<?php
/**
*Module Name:posts
*Date:2015/03/11 12:55:14
*ChangedOrUpdated:Several Files.
*1-Added Support For CanonicalURL
*2-Added Some Changes To Better Theme Customization
**/
?>
<?php
/**
*Module Name:posts
*Date:2015/04/02 12:04:14
*ChangedOrUpdated:asriranHealthCrawler
*1-changed getPostsArray to remove advertise links
**/
?>
<?php
/**
*Module Name:posts
*Date:2016/03/04 15:28:00
*ChangedOrUpdated:postmanageController,PostManageCTL
*1-changed Time Formats to unix based time
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.109
*Module Name:posts
*Date:2016/05/13 16:40:00
*ChangedOrUpdated:clearcache
**/
?>
