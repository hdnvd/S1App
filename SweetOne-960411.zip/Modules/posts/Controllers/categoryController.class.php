<?php

namespace Modules\posts\Controllers;
use core\CoreClasses\services\Controller;
use Modules\posts\Entity\posts_categoryEntity;
use Modules\posts\Entity\posts_languagecategoryEntity;
use Modules\languages\PublicClasses\CurrentLanguageManager;


class categoryController extends Controller {
	public function load()
	{
		return null;
	}
}
?>
