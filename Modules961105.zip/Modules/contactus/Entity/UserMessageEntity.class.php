<?php

namespace Modules\contactus\Entity;

use core\CoreClasses\services\EntityClass;

/**
 *
 * @author nahavandi
 *        
 */
class UserMessageEntity extends EntityClass {
	// TODO - Insert your code here
}

?>