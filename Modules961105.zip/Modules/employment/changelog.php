<?php
/**
*SweetFrameworkHelper Version 1.103
*Module Name:employment
*Date:2015/06/25 19:34:07
*ChangedOrUpdated:bannerkeyword Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.103
*Module Name:employment
*Date:2015/06/25 19:38:46
*ChangedOrUpdated:employer Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.103
*Module Name:employment
*Date:2015/06/25 19:39:12
*ChangedOrUpdated:keyword Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.103
*Module Name:employment
*Date:2015/06/25 19:40:40
*ChangedOrUpdated:preemployee Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.103
*Module Name:employment
*Date:2015/06/25 19:41:47
*ChangedOrUpdated:preemployeekeyword Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.103
*Module Name:employment
*Date:2015/06/25 19:42:49
*ChangedOrUpdated:employbanner Entity Class
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.104
*Module Name:employment
*Date:2015/06/26 18:03:08
*ChangedOrUpdated:employer
**/
?>
<?php
/**
*SweetFrameworkHelper Version 1.105
*Module Name:employment
*Date:2015/06/28 11:26:00
*ChangedOrUpdated:registeremployee
**/
?>
