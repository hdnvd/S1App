<?php

namespace Modules\database\Controllers;
use core\CoreClasses\services\Controller;


class importController extends Controller {
	public function load()
	{
		return null;
	}
}
?>
