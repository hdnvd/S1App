<?php

namespace Modules\mail\Entity;

/**
 *
 * @author nahavandi
 *        
 */
class BoxType
{
	const Inbox=1;
	const Sent=2;
	const UserFolder=2;
}

?>