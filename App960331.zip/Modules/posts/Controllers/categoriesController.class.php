<?php

namespace Modules\posts\Controllers;
use core\CoreClasses\services\Controller;


class categoriesController extends Controller {
	public function load()
	{
		return null;
	}
}
?>
