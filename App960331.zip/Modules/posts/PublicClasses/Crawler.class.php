<?php

namespace Modules\posts\PublicClasses;

/**
 *
 * @author nahavandi
 *        
 */
class Crawler {
	public function getPostsArray()
	{
		return null;
	}
}

?>