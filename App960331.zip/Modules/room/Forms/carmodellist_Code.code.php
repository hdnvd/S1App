<?php
namespace Modules\room\Forms;
use core\CoreClasses\services\FormCode;
use Modules\languages\PublicClasses\ModuleTranslator;
use Modules\languages\PublicClasses\CurrentLanguageManager;
use core\CoreClasses\Exception\DataNotFoundException;
use Modules\room\Controllers\carmodellistController;
use Modules\files\PublicClasses\uploadHelper;
use Modules\common\Forms\message_Design;
/**
*@author Hadi AmirNahavandi
*@creationDate 1396-03-30 - 2017-06-20 04:41
*@lastUpdate 1396-03-30 - 2017-06-20 04:41
*@SweetFrameworkHelperVersion 2.001
*@SweetFrameworkVersion 2.001
*/
class carmodellist_Code extends FormCode {
	public function load()
	{
		$carmodellistController=new carmodellistController();
		$translator=new ModuleTranslator("room");
		$translator->setLanguageName(CurrentLanguageManager::getCurrentLanguageName());
		try{
		$Result=$carmodellistController->load($this->getHttpGETparameter('pn',-1));
		$design=new carmodellist_Design();
		$design->setData($Result);
		$design->setMessage("");
		}
		catch(\Exception $uex){
			$design=new message_Design();
			$design->setMessage("متاسفانه خطایی در اجرای دستور خواسته شده بوجود آمد.");
		}
		return $design->getBodyHTML();
	}
}
?>