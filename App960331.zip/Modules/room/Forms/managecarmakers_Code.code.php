<?php
namespace Modules\room\Forms;
use core\CoreClasses\services\FormCode;
use Modules\languages\PublicClasses\ModuleTranslator;
use Modules\languages\PublicClasses\CurrentLanguageManager;
use Modules\room\Controllers\managecarmakersController;
use Modules\files\PublicClasses\uploadHelper;
/**
*@author Hadi AmirNahavandi
*@creationDate 1396-03-30 - 2017-06-20 03:06
*@lastUpdate 1396-03-30 - 2017-06-20 03:06
*@SweetFrameworkHelperVersion 2.001
*@SweetFrameworkVersion 2.001
*/
class managecarmakers_Code extends FormCode {
	public function load()
	{
		$managecarmakersController=new managecarmakersController();
		$translator=new ModuleTranslator("room");
		$translator->setLanguageName(CurrentLanguageManager::getCurrentLanguageName());
		if(isset($_GET['delete']))
			$Result=$managecarmakersController->DeleteItem($this->getID());
		else{
			$Result=$managecarmakersController->load($this->getHttpGETparameter('pn',-1));
		}
		$design=new managecarmakers_Design();
		$design->setData($Result);
		$design->setMessage("");
		return $design->getBodyHTML();
	}
	public function getID()
	{
		$id=-1;
		if(isset($_GET['id']))
			$id=$_GET['id'];
		return $id;
	}
}
?>