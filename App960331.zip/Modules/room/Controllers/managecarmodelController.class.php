<?php
namespace Modules\room\Controllers;
use core\CoreClasses\services\Controller;
use core\CoreClasses\Exception\DataNotFoundException;
use core\CoreClasses\db\dbaccess;
use Modules\languages\PublicClasses\CurrentLanguageManager;
use Modules\users\PublicClasses\sessionuser;
use core\CoreClasses\db\QueryLogic;
use Modules\room\Entity\room_carmodelEntity;
use Modules\room\Entity\room_carmakerEntity;
use Modules\room\Entity\room_logoEntity;
/**
*@author Hadi AmirNahavandi
*@creationDate 1396-03-30 - 2017-06-20 04:41
*@lastUpdate 1396-03-30 - 2017-06-20 04:41
*@SweetFrameworkHelperVersion 2.001
*@SweetFrameworkVersion 2.001
*/
class managecarmodelController extends Controller {
	public function load($ID)
	{
		$Language_fid=CurrentLanguageManager::getCurrentLanguageID();
		$DBAccessor=new dbaccess();
		$su=new sessionuser();
		$role_systemuser_fid=$su->getSystemUserID();
		$result=array();
		$carmodelEntityObject=new room_carmodelEntity($DBAccessor);
			$carmakerEntityObject=new room_carmakerEntity($DBAccessor);
			$result['carmaker_fid']=$carmakerEntityObject->FindAll(new QueryLogic());
		if($ID!=-1){
			$carmodelEntityObject->setId($ID);
			if($carmodelEntityObject->getId()==-1)
				throw new DataNotFoundException();
			$result['carmodel']=$carmodelEntityObject;
		}
		$result['param1']="";
		$DBAccessor->close_connection();
		return $result;
	}
	public function BtnSave($ID,$carmaker_fid,$latintitle,$title,$logo_flu)
	{
		$Language_fid=CurrentLanguageManager::getCurrentLanguageID();
		$DBAccessor=new dbaccess();
		$su=new sessionuser();
		$role_systemuser_fid=$su->getSystemUserID();
		$result=array();
		if($ID==-1){
			$carmodelEntityObject=new room_carmodelEntity($DBAccessor);
			$carmodelEntityObject->setCarmaker_fid($carmaker_fid);
			$carmodelEntityObject->setLatintitle($latintitle);
			$carmodelEntityObject->setTitle($title);
			$carmodelEntityObject->setLogo_flu($logo_flu[0]['url']);
			$carmodelEntityObject->Save();
		}
		else{
			$carmodelEntityObject=new room_carmodelEntity($DBAccessor);
			$carmodelEntityObject->setId($ID);
			if($carmodelEntityObject->getId()==-1)
				throw new DataNotFoundException();
			$carmodelEntityObject->setCarmaker_fid($carmaker_fid);
			$carmodelEntityObject->setLatintitle($latintitle);
			$carmodelEntityObject->setTitle($title);
			$carmodelEntityObject->setLogo_flu($logo_flu[0]['url']);
			$carmodelEntityObject->Save();
		}
		$result=$this->load($ID);
		$result['param1']="";
		$DBAccessor->close_connection();
		return $result;
	}
}
?>