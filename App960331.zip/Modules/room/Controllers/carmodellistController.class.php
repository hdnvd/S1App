<?php
namespace Modules\room\Controllers;
use core\CoreClasses\services\Controller;
use core\CoreClasses\Exception\DataNotFoundException;
use core\CoreClasses\db\dbaccess;
use Modules\languages\PublicClasses\CurrentLanguageManager;
use Modules\users\PublicClasses\sessionuser;
use core\CoreClasses\db\QueryLogic;
use Modules\room\Entity\room_carmodelEntity;
/**
*@author Hadi AmirNahavandi
*@creationDate 1396-03-30 - 2017-06-20 04:41
*@lastUpdate 1396-03-30 - 2017-06-20 04:41
*@SweetFrameworkHelperVersion 2.001
*@SweetFrameworkVersion 2.001
*/
class carmodellistController extends Controller {
	private $PAGESIZE=10;
	public function load($PageNum)
	{
		$Language_fid=CurrentLanguageManager::getCurrentLanguageID();
		$DBAccessor=new dbaccess();
		$su=new sessionuser();
		$role_systemuser_fid=$su->getSystemUserID();
		$result=array();
		if($PageNum<=0)
			$PageNum=1;
		$carmodelEnt=new room_carmodelEntity($DBAccessor);
		$q=new QueryLogic();
		$allcount=$carmodelEnt->FindAllCount($q);
		$result['pagecount']=$this->getPageCount($allcount,$this->PAGESIZE);
		$q->setLimit($this->getPageRowsLimit($PageNum,$this->PAGESIZE));
		$result['data']=$carmodelEnt->FindAll($q);
		$result['param1']="";
		$DBAccessor->close_connection();
		return $result;
	}
}
?>